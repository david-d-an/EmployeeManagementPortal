﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Net.Http.Headers;
using IdentityServer4.Services;
using EMP.Sts.Data;
using EMP.Sts.Models;
using EMP.Sts.Quickstart.Account;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace EMP.Sts
{
    public class Startup
    {
        private readonly string EmpWebOrigins = "EMP.Web";

        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicationDbContext>(option =>
                option.UseMySQL(Configuration.GetConnectionString("DefaultConnection")));

            services.AddIdentity<ApplicationUser, IdentityRole>()
                .AddEntityFrameworkStores<ApplicationDbContext>()
                .AddDefaultTokenProviders();

            services.AddCors(options =>
            {
                options.AddPolicy(EmpWebOrigins, corsBuilder =>
                {
                    corsBuilder
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    // .AllowAnyOrigin()
                    .SetIsOriginAllowed(_ => true)
                    // .SetIsOriginAllowed(origin => origin == "http://localhost:4200")
                    .AllowCredentials();
                    // corsBuilder
                    // // .AllowAnyHeader()
                    // .WithHeaders(HeaderNames.AccessControlAllowHeaders, "Content-Type")
                    // // .AllowAnyOrigin()
                    // .WithOrigins(
                    //     "http://localhos:5000",
                    //     "https://localhost:5001",
                    //     "http://ipv4.fiddler:5000",
                    //     "https://ipv4.fiddler:5001"
                    // )
                    // // .AllowAnyMethod()
                    // .WithMethods("GET", "PUT", "POST", "DELETE")
                    // .AllowCredentials();
                });
            });

            services.AddMvc();

            services.AddTransient<IProfileService, CustomProfileService>();


            var builder = services.AddIdentityServer(options => {
                options.Events.RaiseErrorEvents = true;
                options.Events.RaiseInformationEvents = true;
                options.Events.RaiseFailureEvents = true;
                options.Events.RaiseSuccessEvents = true;
                options.Authentication.CookieLifetime = TimeSpan.FromMinutes(15);
                options.Authentication.CheckSessionCookieName = "IDS4_EMP.Sts";
            })
            .AddInMemoryIdentityResources(Config.GetIdentityResources())
            .AddInMemoryApiResources(Config.GetApiResources())
            .AddInMemoryClients(Config.GetClients())
            .AddAspNetIdentity<ApplicationUser>()
            .AddProfileService<CustomProfileService>();

            builder.AddDeveloperSigningCredential();


            // services.ConfigureApplicationCookie(options => {
            //     options.ExpireTimeSpan = TimeSpan.FromDays(30);
            // });
            // services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
            //         .AddCookie(options => {
            //             options.LoginPath = "/Login/Account/";
            //         });

            services
            .ConfigureApplicationCookie(options => {
                options.ExpireTimeSpan = TimeSpan.FromDays(30);
                // options.LoginPath = $"/Account/Login";
                // options.LogoutPath = $"/Account/Logout";
                // options.AccessDeniedPath = $"/Account/AccessDenied";
            });

            services
            .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
            .AddCookie("CookieAuthentication", options => {
                options.LoginPath = "/Account/Login/";
            });
            // services
            // .AddAuthentication("CookieAuthentication")  
            // .AddCookie("CookieAuthentication", options =>  
            // {  
            //     options.LoginPath = "/Account/Login/";
            // });  
  

            // if (Environment.IsDevelopment())
            // if (HostingEnvironment.IsDevelopment())
            // {
            //     builder.AddDeveloperSigningCredential();
            // }
            // else
            // {
            //     throw new Exception("need to configure key material");
            // }
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseIdentityServer();

            app.UseCors(EmpWebOrigins);

            app.UseHttpsRedirection();
            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                // endpoints.MapControllers();
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}"
                );
            });
        }
    }
}
